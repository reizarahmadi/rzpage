---
layout: default
title: Beranda
---

# Selamat datang di Kebun Digital Eja

Ini adalah digital garden versi ringan.  
Silakan mulai dengan [catatan pertama](notes/hidup-lebih-pelan).
