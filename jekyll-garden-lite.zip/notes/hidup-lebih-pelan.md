---
title: Hidup Lebih Pelan
---

Ini adalah contoh catatan pertama.  
Kamu bisa menulis refleksi, kutipan, atau pemikiran bebas di sini.
